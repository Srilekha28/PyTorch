# author : Srilekha Bandaru
# a testing model to check the functionality of TorchScriptProfiler
from transformers import BertTokenizer, BertModel
import numpy as np
import torch
from time import perf_counter
import matplotlib.pyplot as plt

totalRange = 100

script_tokenizer = BertTokenizer.from_pretrained('bert-base-uncased', torchscript=True)
script_model = BertModel.from_pretrained("bert-base-uncased", torchscript=True)

# Tokenizing input text
text = "[CLS] Did you like Software Architecture ? [SEP] Yes I like Software Architecture [SEP]"
tokenized_text = script_tokenizer.tokenize(text)

# Masking one of the input tokens
masked_index = 8

tokenized_text[masked_index] = '[MASK]'

indexed_tokens = script_tokenizer.convert_tokens_to_ids(tokenized_text)

segments_ids = [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1]

# Creating a dummy input
tokens_tensor = torch.tensor([indexed_tokens])
segments_tensors = torch.tensor([segments_ids])


native_model = BertModel.from_pretrained("bert-base-uncased")
traced_model = torch.jit.trace(script_model, [tokens_tensor, segments_tensors])

torchScriptProfiler = torch.jit.TorchScriptProfiler(native_model, traced_model, tokens_tensor, segments_tensors)
torchScriptProfiler.run(10, True)

torch.jit.save(traced_model,"traced_bert.pt")

