import torch
import torch.nn.functional as F
import torchvision.transforms as transforms
import torchvision.models as models

import captum
from captum.attr import IntegratedGradients, Occlusion, LayerGradCam, LayerAttribution
from captum.attr import visualization as viz

import os, sys
import json

import numpy as np
from PIL import Image
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap

IMG_SIZE = 224
IMG_NET_MEAN = [0.485, 0.456, 0.406]
IMG_NET_STD = [0.229, 0.224, 0.225]


class FeatureLayerAttribution:
	# model expects 224x224 3-color image
	transform = transforms.Compose([
		 transforms.Resize(IMG_SIZE),
		 transforms.CenterCrop(IMG_SIZE),
		 transforms.ToTensor()
		])
	normalizer = transforms.Normalize(mean=IMG_NET_MEAN, std=IMG_NET_STD)

	def __init__(self, model, test_img, label_idxs):
		self.model = model
		if self.model is not None:
			self.model = self.model.eval()

		self.transform_img = FeatureLayerAttribution.transform(Image.open(test_img))
		self.img = FeatureLayerAttribution.normalizer(self.transform_img).unsqueeze(0)
		self.label_idxs = label_idxs


	def predict(self):
		self.output = F.softmax(self.model(self.img), dim=1)
		_ , self.pred_label_idx = torch.topk(self.output, 1)
		self.pred_label_idx.squeeze()


	def feature_attribution_properties(self):
		self.occlusion = Occlusion(self.model)
		self.attributions_occ = self.occlusion.attribute(self.img,
                                       target=self.pred_label_idx,
                                       strides=(3, 8, 8),
                                       sliding_window_shapes=(3,15, 15),
                                       baselines=0)

		_ = viz.visualize_image_attr_multiple(np.transpose(self.attributions_occ.squeeze().cpu().detach().numpy(), (1,2,0)),
                                      np.transpose(self.transform_img.squeeze().cpu().detach().numpy(), (1,2,0)),
                                      ["original_image", "heat_map", "heat_map", "masked_image"],
                                      ["all", "positive", "negative", "positive"],
                                      show_colorbar=True,
                                      titles=["Original", "Positive Attribution", "Negative Attribution", "Masked"],
                                      fig_size=(18, 6)
                                     )


	def layer_attribution_properties(self):
		self.layer_gradcam = LayerGradCam(self.model, self.model.layer3[1].conv2)
		self.attributions_lgc = self.layer_gradcam.attribute(self.img, target=self.pred_label_idx)
		self.upsamp_attr_lgc = LayerAttribution.interpolate(self.attributions_lgc, self.img.shape[2:])
		_ = viz.visualize_image_attr_multiple(self.upsamp_attr_lgc[0].cpu().permute(1,2,0).detach().numpy(),
                                      self.transform_img.permute(1,2,0).numpy(),
                                      ["original_image","blended_heat_map","masked_image"],
                                      ["all","positive","positive"],
                                      show_colorbar=True,
                                      titles=["Original", "Positive Attribution", "Masked"],
                                      fig_size=(18, 6))


	def render_attribution_properties(self):
		self.predict()
		self.feature_attribution_properties()
		self.layer_attribution_properties()
