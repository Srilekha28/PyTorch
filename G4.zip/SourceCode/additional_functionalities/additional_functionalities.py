# Author: Fahmeedha Apparawthar Azmathullah

import os
import torch 
from torch import nn
import torch.quantization
import torch.nn.functional as F
import warnings
torch.backends.quantized.engine = 'qnnpack'
warnings.filterwarnings('ignore')

class LeNet5(nn.Module):
    def __init__(self):
        super(LeNet5, self).__init__()
        self.conv1 = nn.Conv2d(3, 6, 5)
        self.conv2 = nn.Conv2d(6, 16, 5)
        self.fc1 = nn.Linear(16 * 5 * 5, 120)
        self.fc2 = nn.Linear(120, 84)
        self.fc3 = nn.Linear(84, 10)

    def forward(self, x):
        x = F.max_pool2d(
            F.relu(self.conv1(x)), (2, 2))
        x = F.max_pool2d(
            F.relu(self.conv2(x)), 2)
        x = x.view(-1, 
                   int(x.nelement() / x.shape[0]))
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = self.fc3(x)
        return x

fp32_model = LeNet5()
# print(fp32_model)

for n, p in fp32_model.named_parameters():
    print(n, ": ", p.dtype)

#dynamic quantization

quantized_model = torch.quantization.quantize_dynamic(
      fp32_model, 
      {torch.nn.Linear},
      dtype=torch.qint8)

# print(quantized_model)

#static quantization

static_quant_model = LeNet5()
static_quant_model.qconfig = torch.quantization.get_default_qconfig('fbgemm')

torch.quantization.prepare(
    static_quant_model, inplace=True)
torch.quantization.convert(
    static_quant_model, inplace=True)
# print(static_quant_model)

#quantization aware training

qat_model = LeNet5()
torch.quantization.get_default_qat_qconfig('fbgemm')  
qconfig = torch.quantization.get_default_qat_qconfig('fbgemm')

torch.quantization.prepare_qat(
    qat_model, inplace=True)
torch.quantization.convert(
    qat_model, inplace=True)

# print(qat_model)

# This method returns the size of the model

def size_of_model(model, label=""):
    torch.save(model.state_dict(), "temp.p")
    size=os.path.getsize("temp.p")
    print("model: ",label,' \t','Size (KB):', size/1e3)
    os.remove('temp.p')
    return size

# This method return the datatype of the given model

def dtype_of_model(model, label=""):
    torch.save(model.state_dict(), "tem.p")
    p in model.named_parameters()
    datatype=p.dtype
    print("The data type of the given model", label, "is", datatype)
    return datatype

# This method is to check whether the given path is a regular fileformat

def sanity_check(model):
    torch.save(model.state_dict(), "te.p")
    fileCheck=os.path.isfile("te.p")
    print("Given model path is regular: ",fileCheck)
    return fileCheck

# compare the sizes

g=size_of_model(static_quant_model,"static quantization-fp32")
q=size_of_model(quantized_model,"dynamic_quantization-int8")
qat=size_of_model(qat_model,"qat-fp32")

#printing the datatype of the model

dtype_of_model(fp32_model,"fp32")

#printing whether the given path of a model is in regular file

sanity_check(fp32_model)

